class NotRegistered (Exception):
    ...


class InvalidInput  (Exception):
    ...


class TooRequests   (Exception):
    ...


class InvalidAuth   (Exception):
    ...
